# Merc's Lair — native Android live wallpaper

An original-image-based **2.5D live wallpaper** for the Galaxy S26 Ultra, implemented in Kotlin using Android's `WallpaperService` and GPU-backed Canvas. No Unity engine, advertising SDK, analytics, location permission, internet permission or background service required.

## Included features

- **Source image retained:** the approved realistic cooling-tower artwork lives in `reference/mercs_lair_original.png`.
- **Animated photographic fan:** `fan_rotor.png` contains real metal and blade pixels extracted from the source; its rotational plane is projected back into the photograph's ceiling aperture. The pole and motor housing remain stationary.
- **Gyroscope parallax:** an authored low-amplitude depth mesh, updated from `TYPE_GAME_ROTATION_VECTOR` where available, rather than large fake camera translations. If no sensor is available, the original image remains visible and the fan still animates.
- **Automatic time-based lighting:** smoothly switches between daylight, warm dusk and a cooler nighttime scene, according to the phone's **local clock**. No GPS/location permission. Sunrise/sunset hours are adjustable.
- **Night monitor illumination:** subtle blue glow around the central monitors.
- **Performance:** selectable 10–30 FPS (24 default); rendering and sensor tracking stop when the wallpaper is hidden. The screen-off/hidden behavior depends on the launcher's wallpaper visibility callbacks.
- **Native settings:** fan toggle and RPM, depth motion toggle and intensity, lighting presets, sunrise/sunset hours and FPS.

## Build on Windows

1. Install **Android Studio**, with Android SDK **API 35**, Android SDK Build-Tools, and **JDK 17** (Android Studio's embedded JDK is typically suitable).
2. Open the project directory in Android Studio. The repo intentionally omits the binary `gradle-wrapper.jar`; it can be regenerated from the official Gradle distribution.
3. In PowerShell, run:
   ```powershell
   Set-ExecutionPolicy -Scope Process Bypass
   .\scripts\build-windows.ps1
   ```
   The helper downloads Gradle 8.9 from `services.gradle.org`, generates the **official** Gradle wrapper, and runs `assembleDebug`. An internet connection is required on this **first** build to obtain Gradle and Android plugin dependencies.
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer the APK to the Galaxy S26 Ultra. Install it (grant install permission for the file manager only if needed), open **Merc's Lair**, customize settings and tap **Set live wallpaper**.

On macOS/Linux, if Gradle 8.9 is installed, use `scripts/build-unix.sh` or run `gradle wrapper --gradle-version 8.9 && ./gradlew assembleDebug`.

### Optional cloud build (no local Android SDK)

Push the project files to a GitHub repository and run **Actions → Build Android APK → Run workflow**. The included `.github/workflows/android.yml` installs SDK API 35, builds the debug APK and publishes an artifact named `MercsLair-debug-APK`. This is an **optional user-initiated build**, not something that has been executed or verified in this environment.

### Android Studio sync tip

If Android Studio reports a missing Gradle wrapper JAR before the first build, run the Windows helper above to regenerate it, then re-open/sync the project. `local.properties` with `sdk.dir` may be created automatically by Android Studio.

## Assets

`app/src/main/assets/`:
- `scene_base.webp`: reconstructs the portion of sky behind the rotating fan while keeping the rest of the photo intact.
- `fan_rotor.png`: keyed photo texture in a circular plane; rendered with elliptical perspective.
- `hub_pole.png`: stationary shaft/hub overlay.
- `depth.png`: low-resolution authored depth map for the warping mesh.

The source and re-generation script are included. Run `python scripts/make_assets.py` (Pillow, numpy, opencv-python) to regenerate the assets. Re-generated assets may differ slightly from the included ones when image libraries/versions differ.

## Key source files

`MercsLairService.kt` — live wallpaper lifecycle, sensors, renderer, light blending, FPS control and fan.

`SettingsActivity.kt` — configuration screen & live wallpaper chooser.

`ScenePreferences.kt` — stored user settings.

## Engineering notes and limitations

- This is a **working-source prototype**, not a device-tested release: the Android SDK/Gradle were unavailable in the authoring environment, so an APK could not be compiled or device-tested here. Run the build locally and test before treating it as finished.
- This is **2.5D photo displacement**, not a fully reconstructed 3D model. Extreme angles are intentionally clamped and will not reveal unseen geometry.
- The fan texture is extracted with image-based chroma separation. Some image reconstruction seams may remain around the original aperture; the approximation is not a true optical simulation.
- Night lighting is artistically graded, not a real-time illumination engine. The brightness schedule uses customizable clock hours, not actual solar position/weather.
- On some One UI builds, gyroscope wallpaper motion or touch may behave differently in **lock-screen** previews. Home-screen live wallpaper is the primary target.
- Compatibility should be validated on the target S26 Ultra, including battery, AOD behavior and wallpaper chooser support.

## License / image provenance

The artwork was previously generated for the user in this conversation. This is an independent fan project, not affiliated with the Mirror's Edge publishers. No game assets or third-party SDKs are bundled.
