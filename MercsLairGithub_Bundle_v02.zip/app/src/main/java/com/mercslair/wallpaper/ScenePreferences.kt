package com.mercslair.wallpaper

import android.content.Context
import android.content.SharedPreferences

internal object ScenePreferences {
    const val MOTION_ENABLED = "motionEnabled"
    const val MOTION_STRENGTH = "motionStrength"
    const val FAN_ENABLED = "fanEnabled"
    const val FAN_SPEED = "fanSpeed"
    const val LIGHT_MODE = "lightMode"
    const val FPS = "fps"
    const val SUNRISE = "sunrise"
    const val SUNSET = "sunset"

    fun get(context: Context): SharedPreferences =
        context.getSharedPreferences("mercs_lair", Context.MODE_PRIVATE)
}
