"""Rebuild v0.2 scene from the approved photographic wallpaper.

The scene sky and architecture are stationary. Only metallic blades are
segmented into a foreground RGBA rotor and rotated in the app.
"""
from pathlib import Path
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFilter

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'app/src/main/assets'
SOURCE=Path('/mnt/data/merc_s_futuristic_skyline_lair.png')
ORIG=cv2.imread(str(SOURCE))
assert ORIG is not None and ORIG.shape[:2]==(1822,863)
h,w=ORIG.shape[:2]
# Fan sits inside oval aperture; pivot aligned with fixed shaft.
CX,CY=491,922
SX,SY=276.0,177.0
polys=[
    # upper-left blade, right side runs into hub
    [(248,843),(259,813),(281,793),(314,790),(458,858),(477,888),(476,903),(447,886)],
    # upper-right blade
    [(492,871),(507,816),(533,748),(586,747),(552,826),(514,898),(492,908),(485,884)],
    # right-hand blade
    [(526,882),(598,886),(767,888),(764,952),(594,949),(531,944),(516,927)],
    # lower-right blade
    [(518,942),(552,970),(573,1006),(609,1098),(561,1093),(523,1015),(501,968)],
    # lower-left blade
    [(463,935),(417,943),(363,965),(296,994),(256,1036),(279,1056),(318,1045),(449,974),(475,955)],
]
# Aperture is a foreshortened ellipse. Its background must never rotate.
Y,X=np.mgrid[:h,:w]
CX,CY=491,922
SX,SY=274.0,172.0
radial=((X-500)/SX)**2+((Y-917)/SY)**2
opening=radial<.94**2
# The blue, original sky is retained verbatim everywhere it was visible.
# Only existing metallic rotor pixels need their colors reconstructed.
b,g,r=cv2.split(ORIG.astype(np.float32))
ratio=(r+8)/(b+8)
metal=opening & (ratio>.57)
# Smooth polygons are used as a prior to ensure we never pick architecture
# or wispy clouds as separate spinning objects.
poly=np.zeros((h,w),np.uint8)
for p in polys: cv2.fillPoly(poly,[np.asarray(p,np.int32)],255)
# Include broad blade footprints for replacement, avoiding stationary mast and hub.
mask=np.uint8(metal)*255
mask=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))
mask=cv2.dilate(mask,np.ones((5,5),np.uint8),iterations=1)
fixed=np.zeros((h,w),np.uint8)
cv2.ellipse(fixed,(493,922),(61,58),0,0,360,255,-1)
cv2.fillPoly(fixed,[np.asarray([(479,920),(512,920),(515,1160),(481,1160)],np.int32)],255)
mask[fixed>0]=0
# Fit a smooth sky from actual, unobscured BLUE pixels within aperture.
# Fill masked original metal only; all unmasked sky pixels remain bit-identical.
valid=opening & (ratio<.48) & (b>140)
yv,xv=np.where(valid);yv=yv[::4];xv=xv[::4]
terms=lambda x,y: np.stack([np.ones_like(x),x,y,x*x,y*y,x*y,x*x*y,y*y*x],axis=-1)
A=terms((xv-CX)/SX,(yv-CY)/SY)
xxn=(X-CX)/SX;yyn=(Y-CY)/SY
clean=ORIG.copy()
inds=np.where(mask>0)
Ak=terms(xxn[inds],yyn[inds])
for channel in range(3):
    coef=np.linalg.lstsq(A,ORIG[yv,xv,channel],rcond=None)[0]
    vals=np.clip(Ak@coef,0,255).astype(np.uint8)
    clean[inds[0],inds[1],channel]=vals
# A small smooth transition at the photographic boundary without altering other sky.
alpha_inpaint=cv2.GaussianBlur(mask,(5,5),1.0).astype(np.float32)/255
clean=(clean.astype(np.float32)*alpha_inpaint[:,:,None]+ORIG.astype(np.float32)*(1-alpha_inpaint[:,:,None])).astype(np.uint8)
# Extract blade-only pixels by selecting metal in the five source blade zones.
metal_orig=((ratio>.59) & opening).astype(np.uint8)*255
blade=cv2.bitwise_and(metal_orig,poly)
blade=cv2.morphologyEx(blade,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))
blade=cv2.dilate(blade,np.ones((3,3),np.uint8),iterations=1)
blade[fixed>0]=0
blade=cv2.GaussianBlur(blade,(3,3),.6)
rotor=cv2.cvtColor(ORIG,cv2.COLOR_BGR2BGRA)
rotor[:,:,3]=blade
size=768
xx,yy=np.meshgrid(np.arange(size,dtype=np.float32),np.arange(size,dtype=np.float32))
source_x=CX+(xx-size/2)*(2*SX/size)
source_y=CY+(yy-size/2)*(2*SY/size)
rotor_circular=cv2.remap(rotor,source_x,source_y,cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0,0))
# Build an optically consistent 5-blade brushed-metal rotor. The source photo
# contains uneven perspective/duplicated blades. Creating a single radial rotor
# geometry and projecting to the aperture prevents floating or tearing blades.
size=768
yy,xx=np.mgrid[:size,:size].astype(np.float32)
dx=(xx-size/2);dy=(yy-size/2)
R=(size/2-12)
blade_rgba=np.zeros((size,size,4),np.float32)
np.random.seed(16)
noise=cv2.GaussianBlur(np.random.standard_normal((size,size)).astype(np.float32),(3,3),.6)
for blade_i in range(5):
    a=np.deg2rad(9.0+blade_i*72.0)
    rr=(dx*np.cos(a)+dy*np.sin(a))/R
    tt=(-dx*np.sin(a)+dy*np.cos(a))/R
    t=(rr-.15)/(.88-.15)
    center=-.055*t+.012*np.sin(t*np.pi)
    taper=np.minimum(1.0,np.minimum(np.maximum(t/.045,0),np.maximum((1-t)/.075,0)))
    half=(.06+.077*np.clip(t,0,1))*np.sqrt(np.maximum(0,taper))
    u=(tt-center)/(half+1e-6)
    inside=(t>=0)&(t<=1)&(np.abs(u)<=1)&(rr>0)
    # Realistic cambered metal with longitudinal polishing marks and soft specular highlight
    value=(94+14*(1-u*u)+58*np.exp(-((u+.69)/.35)**2)
           -18*np.exp(-((u-.9)/.16)**2)+2.5*np.sin(rr*33+tt*10)
           +2.0*noise+3*np.cos(a))
    value=np.clip(value,28,235)
    edge_alpha=np.clip((1-np.abs(u))*max(1.0,size/320),0,1)*np.clip(t*65,0,1)*np.clip((1-t)*65,0,1)
    edge_alpha=np.where(inside,edge_alpha,0)
    # Non-premultiplied RGBA; texture is treated as pure metallic, not sky.
    blade_rgba[:,:,0]=np.where(inside,value*1.035,blade_rgba[:,:,0]) # blue
    blade_rgba[:,:,1]=np.where(inside,value*1.016,blade_rgba[:,:,1])
    blade_rgba[:,:,2]=np.where(inside,value*.97,blade_rgba[:,:,2])
    blade_rgba[:,:,3]=np.maximum(blade_rgba[:,:,3],edge_alpha*255)
rotor_circular=np.clip(blade_rgba,0,255).astype(np.uint8)
# Root fasteners, dynamically spinning with the blade assembly.
for j in range(5):
    a=np.deg2rad(9+j*72)
    rx=int(size/2+.18*R*np.cos(a));ry=int(size/2+.18*R*np.sin(a))
    cv2.circle(rotor_circular,(rx,ry),5,(65,72,76,240),-1,lineType=cv2.LINE_AA)
    cv2.circle(rotor_circular,(rx,ry),2,(165,174,183,255),-1,lineType=cv2.LINE_AA)
# Stationary hub + shaft foreground sprite, original photo exactly, with alpha.
# A mask follows the cylindrical shaft and the round motor geometry.
mask=np.zeros((h,w),np.uint8)
cv2.ellipse(mask,(491,917),(54,47),0,0,360,255,-1)
# Make sure the slender pole never passes behind the moving rotor.
pole=[(482,944),(500,944),(508,1027),(506,1118),(499,1135),(485,1125),(482,1058)]
cv2.fillPoly(mask,[np.array(pole,np.int32)],255)
# hub center and vertical shaft overlap smooth
mask=cv2.GaussianBlur(mask,(5,5),1.0)
x0,y0,x1,y1=435,855,555,1160
pole_rgba=cv2.cvtColor(ORIG[y0:y1,x0:x1],cv2.COLOR_BGR2BGRA)
pole_rgba[:,:,3]=mask[y0:y1,x0:x1]
# Fill behind original rotor but NOT hub/shaft. The sky gradient remains still.
scene_rgb=cv2.cvtColor(clean,cv2.COLOR_BGR2RGB)
Image.fromarray(scene_rgb).save(ASSETS/'scene_base.webp',format='WEBP',quality=96,method=6)
cv2.imwrite(str(ASSETS/'fan_rotor.png'),rotor_circular,[cv2.IMWRITE_PNG_COMPRESSION,8])
cv2.imwrite(str(ASSETS/'hub_pole.png'),pole_rgba,[cv2.IMWRITE_PNG_COMPRESSION,8])
# Optional depth map with low-frequency layers: near desk, mid tower, far city.
y,x=np.mgrid[:h,:w]; dm=np.full((h,w),95,dtype=np.uint8)
dm[y>1300]=170;dm[(y>1130)&(y<=1300)]=130;dm[(y>1450)&(x<420)]=190
cv2.ellipse(dm,(501,915),(290,194),0,0,360,60,-1)
dm=cv2.resize(dm,(216,456),interpolation=cv2.INTER_AREA)
Image.fromarray(dm).convert('RGB').save(ASSETS/'depth.png')
# New wallpaper thumbnail: updated photo
Image.fromarray(scene_rgb).resize((440,928)).save(ROOT/'app/src/main/res/drawable/wallpaper_thumbnail.webp',quality=80)
# Create test composite frames with exact Android transform in normalized coords.
from PIL import Image
base=Image.fromarray(scene_rgb).convert('RGBA')
blade_rgba=Image.open(ASSETS/'fan_rotor.png').convert('RGBA')
hub=Image.open(ASSETS/'hub_pole.png').convert('RGBA')
# Remap projected rotor texture by analytic inverse ellipse and angular inverse.
def render(angle):
    rad=np.deg2rad(angle)
    left=max(0,int(CX-SX));top=max(0,int(CY-SY))
    outw=int(2*SX);outh=int(2*SY)
    cx=(np.arange(outw)+left-CX)/(SX)
    cy=(np.arange(outh)+top-CY)/(SY)
    u,v=np.meshgrid(cx,cy)
    srcu=u*np.cos(rad)+v*np.sin(rad)
    srcv=-u*np.sin(rad)+v*np.cos(rad)
    remx=(srcu+1)*size/2
    remy=(srcv+1)*size/2
    arr=np.array(blade_rgba)
    proj=cv2.remap(arr,remx.astype(np.float32),remy.astype(np.float32),cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0,0))
    rr=u*u+v*v
    proj[rr>.98**2,3]=0
    f=base.copy()
    f.alpha_composite(Image.fromarray(proj),dest=(left,top))
    f.alpha_composite(hub,dest=(435,855))
    return f.convert('RGB')
for a in (0,28,67):
    render(a).save('/mnt/data/merc_fan_v02_%02d.jpg'%a,quality=94)
Image.fromarray(cv2.cvtColor(clean,cv2.COLOR_BGR2RGB)).save('/mnt/data/merc_fan_v02_clean.jpg',quality=93)
print('Assets created',[(p.name,p.stat().st_size) for p in ASSETS.iterdir()]);print('Rotor center',CX,CY,'projection radii',SX,SY)
