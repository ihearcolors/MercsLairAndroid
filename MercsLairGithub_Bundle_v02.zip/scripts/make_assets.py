#!/usr/bin/env python3
"""Reconstruct lightweight live-wallpaper layers from the user-approved source image.
Build-time utility: requires Pillow, numpy, opencv-python. Not needed to build the APK.
"""
from PIL import Image, ImageDraw, ImageFilter
import numpy as np
import cv2
from pathlib import Path
import argparse

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'reference'/'mercs_lair_original.png'
OUT = ROOT/'app'/'src'/'main'/'assets'
OUT.mkdir(parents=True,exist_ok=True)

source = Image.open(SRC).convert('RGB')
w,h = source.size
print('Source',w,h)
arr=np.asarray(source).astype(np.float32)
yy,xx=np.mgrid[:h,:w].astype(np.float32)
# Aperture is a perspective ellipse photographed from below.
cx,cy=505.0,946.0
rx,ry=257.0,154.0
ellipse=((xx-cx)/rx)**2+((yy-cy)/ry)**2
inner=ellipse<0.88**2
# Prefer samples of authentic sky (bright cyan-blue, rather than silver-metal fan).
blueness = (arr[:,:,2] - arr[:,:,0])
skyvalid=inner & (blueness>50) & (arr[:,:,2]>140) & ((arr[:,:,2]-arr[:,:,1])>22)
coords=np.column_stack(((xx[skyvalid]-cx)/rx,(yy[skyvalid]-cy)/ry))
# Robust low-order polynomial fit, outliers filtered with clipping. Deterministic.
X=np.column_stack((np.ones(len(coords)),coords[:,0],coords[:,1],coords[:,0]**2,coords[:,0]*coords[:,1],coords[:,1]**2))
Q=np.stack((np.ones((h,w)),(xx-cx)/rx,(yy-cy)/ry,((xx-cx)/rx)**2,((xx-cx)/rx)*((yy-cy)/ry),((yy-cy)/ry)**2),axis=-1)
paint=np.zeros_like(arr)
for c in range(3):
 v=arr[:,:,c][skyvalid]
 coef=np.linalg.lstsq(X,v,rcond=None)[0]
 paint[:,:,c]=np.clip(Q@coef,0,255)
# Keep subtle authentic cloud patches where possible by capturing local sky high frequency.
# A mild gaussian blur avoids creating an artificial smooth, flat oval.
blueSky=cv2.GaussianBlur(arr.astype(np.uint8),(0,0),8).astype(np.float32)
# Blend only selected real sky portions, softly feathered so blades do not ghost through.
validsoft=cv2.GaussianBlur(skyvalid.astype(np.float32),(0,0),3)
# Sky is mainly the estimated low-frequency color. Some cloudy variation is desirable.
paint=0.91*paint + 0.09*blueSky
# preserve aperture metal rim using a 9px feather in ellipse-distance space
alpha=np.clip((0.988-np.sqrt(ellipse))*24,0,1) * (1.0 - np.clip((arr[:,:,0]-158.0)/80.0,0,1))
alpha=alpha[...,None]
combined=np.uint8(np.clip(arr*(1-alpha)+paint*alpha,0,255))
Image.fromarray(combined,'RGB').save(OUT/'scene_base.webp',format='WEBP',quality=96,method=6)

# Reconstitute the stationary motor hub and central steel shaft over animated blades.
static=Image.new('L',(w,h),0); d=ImageDraw.Draw(static)
d.ellipse((461,917,547,995),fill=255)
d.polygon([(497,963),(519,962),(521,1099),(497,1107)],fill=255)
d.polygon([(513,986),(524,999),(526,1063),(519,1068)],fill=180)
static=static.filter(ImageFilter.GaussianBlur(1.7))
rgba=np.dstack((np.asarray(source),np.asarray(static))).astype(np.uint8)
Image.fromarray(rgba,'RGBA').crop((450,904,554,1115)).save(OUT/'hub_pole.png',optimize=True)

# Approximate a smoothly transitioning per-pixel depth field for restrained 2.5D mesh motion.
# This is intentionally approximate: no machine-learned monocular depth inference required.
depth=np.full((h,w),0.54,dtype=np.float32)
depth=np.where(yy>1590,0.65,depth)
depth=np.where((yy>1150)&(yy<1390),0.35,depth)
depth=np.where(ellipse<1,0.24,depth)
# Mechanical column and computer workstation close to viewer.
def poly_into(points,z):
 mask=np.zeros((h,w),dtype=np.uint8)
 cv2.fillPoly(mask,[np.array(points,np.int32)],255)
 depth[mask>0]=z
poly_into([(489,935),(535,935),(540,1362),(474,1362)],0.78)
poly_into([(363,1264),(674,1257),(708,1474),(381,1480)],0.89)
poly_into([(0,1333),(245,1332),(250,1480),(0,1507)],0.91)
poly_into([(267,1348),(378,1353),(412,1530),(241,1535)],0.87)
depth=cv2.GaussianBlur(depth,(0,0),25)
Image.fromarray(np.uint8(np.clip(depth*255,0,255)),'L').resize((213,462),Image.Resampling.LANCZOS).convert('RGB').save(OUT/'depth.png',optimize=True)

# The spinning rotor: optically feathered brushed-metal fan blades, drawn in the unprojected
# circular plane; Canvas flattens it into the skylight's physical ellipse.
S=768; center=S/2
fan_rgba=np.zeros((S,S,4),dtype=np.uint8)
py,px=np.mgrid[:S,:S]

def cubic_bezier(p0,p1,p2,p3,t):
 return (1-t)**3*np.array(p0)+3*(1-t)**2*t*np.array(p1)+3*(1-t)*t*t*np.array(p2)+t**3*np.array(p3)

# Draw four broad swept metal blades with tapered tips and authentic microtexture.
rng=np.random.default_rng(443)
for angle in [16,106,196,286]:
 # base geometry extends 45 to 330 pixels in unprojected radius
 # blade sweep bends clockwise and tapers at tip
 rad=np.radians(angle)
 u=np.array([np.cos(rad),np.sin(rad)])
 v=np.array([-np.sin(rad),np.cos(rad)])
 # polygon in local radial / tangential frame, moderately asymmetric fan shape
 rel=[(33,-39),(88,-58),(145,-84),(225,-95),(287,-70),(327,-32),
      (338,-8),(321,13),(283,22),(221,10),(159,2),(100,20),(40,40)]
 points=[(center + (r*u[0]+t*v[0]),center+(r*u[1]+t*v[1])) for r,t in rel]
 mask=Image.new('L',(S,S),0); md=ImageDraw.Draw(mask)
 md.polygon(points,fill=255)
 mask=mask.filter(ImageFilter.GaussianBlur(1.4))
 m=np.asarray(mask).astype(np.float32)/255
 # directional lighting and brushed texture from geometric coordinates
 dx=px-center; dy=py-center
 radial=(dx*u[0]+dy*u[1]); lateral=(dx*v[0]+dy*v[1])
 per=np.clip((lateral+85)/160,0,1)
 hi=(1-per)*35 + 14*np.sin(radial*.043) + 15*np.sin(lateral*.08) + rng.normal(0,3,(S,S))
 base=105 + hi
 for c,slope in enumerate([.93,1.00,1.12]):
  sample=np.uint8(np.clip(base*slope,0,255))
  fan_rgba[:,:,c]=(fan_rgba[:,:,c].astype(np.float32)*(1-m)+sample*m).astype('uint8')
 fan_rgba[:,:,3]=np.maximum(fan_rgba[:,:,3],np.uint8(m*255))
# Industrial rings/bolts in rotor center
fan_image=Image.fromarray(fan_rgba,'RGBA')
fd=ImageDraw.Draw(fan_image,'RGBA')
fd.ellipse((center-50,center-50,center+50,center+50),fill=(66,71,80,255),outline=(186,191,192,255),width=8)
fd.ellipse((center-28,center-28,center+28,center+28),fill=(122,128,129,255),outline=(42,49,54,255),width=7)
for theta in np.linspace(0,2*np.pi,8,endpoint=False):
 x0=center+38*np.cos(theta);y0=center+38*np.sin(theta)
 fd.ellipse((x0-4,y0-4,x0+4,y0+4),fill=(225,221,210,255))
fan_image.save(OUT/'fan_rotor.png',optimize=True)

# Stock, user-approved source for project provenance/reproducibility.
print('Assets:',[(p.name,round(p.stat().st_size/1024)) for p in OUT.iterdir()])

# Override the backup synthetic geometry with an exact photographic extraction of the original fan.
# Metal-vs-sky chroma key keeps the source metal scratches, reflections and edges.
S=768
sy,sx=np.mgrid[:S,:S].astype(np.float32)
projx=(sx-S/2)*(248/(S/2))+505
projy=(sy-S/2)*(144/(S/2))+946
sampled=cv2.remap(arr,projx.astype(np.float32),projy.astype(np.float32),cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
blueness=sampled[:,:,2]-sampled[:,:,0]
opacity=np.clip((110-blueness)/68,0,1)
radius=np.sqrt(((sx-S/2)/(S/2))**2+((sy-S/2)/(S/2))**2)
opacity*=np.clip((.95-radius)*35,0,1)
opacity*=np.clip((radius-.08)*20,0,1)
opacity[(np.abs(projx-505)<16)&(projy>955)]=0  # stationary steel shaft
opacity=cv2.GaussianBlur(opacity,(0,0),1)
photo_rotor=np.uint8(np.clip(np.dstack((sampled,opacity*255)),0,255))
Image.fromarray(photo_rotor,'RGBA').save(OUT/'fan_rotor.png',optimize=True)
