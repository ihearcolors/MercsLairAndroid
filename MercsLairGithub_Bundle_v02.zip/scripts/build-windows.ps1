# First-run build bootstrap for Windows (requires Android SDK API 35 & JDK 17).
# Downloads Gradle only from the official services.gradle.org distribution URL.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$version = '8.9'
$base = Join-Path $env:LOCALAPPDATA 'MercsLairBuildTools'
$gradleDir = Join-Path $base "gradle-$version"
$gradleExe = Join-Path $gradleDir 'bin\gradle.bat'
if (!(Test-Path $gradleExe)) {
    New-Item -ItemType Directory -Force -Path $base | Out-Null
    $zip = Join-Path $base "gradle-$version-bin.zip"
    Write-Host "Downloading Gradle $version from the official distribution..."
    Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$version-bin.zip" -OutFile $zip
    Expand-Archive -LiteralPath $zip -DestinationPath $base -Force
    Remove-Item $zip
}
if (!(Test-Path $gradleExe)) { throw 'Gradle executable not found after extraction.' }
if (!$env:ANDROID_HOME -and !$env:ANDROID_SDK_ROOT) {
    $sdk = Join-Path $env:LOCALAPPDATA 'Android\Sdk'
    if (Test-Path $sdk) { $env:ANDROID_HOME = $sdk }
}
Push-Location $root
try {
    & $gradleExe wrapper --gradle-version $version --distribution-type bin
    if ($LASTEXITCODE -ne 0) { throw 'Gradle wrapper generation failed.' }
    & (Join-Path $root 'gradlew.bat') assembleDebug
    if ($LASTEXITCODE -ne 0) { throw 'APK build failed. See Gradle error output above.' }
    Write-Host "APK: $root\app\build\outputs\apk\debug\app-debug.apk"
} finally { Pop-Location }
