#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if command -v gradle >/dev/null; then
  gradle wrapper --gradle-version 8.9 --distribution-type bin
else
  echo 'Install Gradle 8.9 or run this in Android Studio; the SDK and Gradle are not bundled.' >&2
  exit 1
fi
./gradlew assembleDebug
printf 'APK: %s/app/build/outputs/apk/debug/app-debug.apk\n' "$PWD"
