package com.mercslair.wallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** No third-party dependencies: the complete control surface is native Android. */
class SettingsActivity : Activity() {
    private val prefs by lazy { ScenePreferences.get(this) }
    private val ink = Color.rgb(239,244,247)
    private val muted = Color.rgb(160,174,182)
    private val red = Color.rgb(240,63,79)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(13,22,30)
        window.navigationBarColor = Color.rgb(13,22,30)

        val scroller = ScrollView(this).apply { setBackgroundColor(Color.rgb(13,22,30)) }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val d = resources.displayMetrics.density
            setPadding((22*d).toInt(), (22*d).toInt(), (22*d).toInt(), (32*d).toInt())
        }
        scroller.addView(content)
        setContentView(scroller)
        content.heading("MERC'S LAIR", 28f)
        content.body("L I V E   W A L L P A P E R", red, 12f)
        content.body("The original rooftop cooling tower, brought to life with subtle depth, photographic fan motion and time-responsive light.")

        content.section("SCENE")
        content.toggle("Enable gyroscope parallax", ScenePreferences.MOTION_ENABLED, true)
        content.slider("Depth movement", ScenePreferences.MOTION_STRENGTH, 0, 100, 45, "%")
        content.toggle("Animate ceiling fan", ScenePreferences.FAN_ENABLED, true)
        content.slider("Fan speed", ScenePreferences.FAN_SPEED, 1, 8, 3, " RPM")

        content.section("LIGHTING")
        val lightingLabels = listOf("Automatic • local phone time", "Bright daylight", "Golden hour", "Night")
        val currentLight = prefs.getInt(ScenePreferences.LIGHT_MODE, 0).coerceIn(0,3)
        val lights = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        lightingLabels.forEachIndexed { index, label ->
            val option = RadioButton(this).apply {
                text = label
                textSize = 15f
                setTextColor(ink)
                id = View.generateViewId()
                isChecked = index == currentLight
                setPadding(0,5,0,5)
            }
            lights.addView(option)
            if (index == currentLight) lights.check(option.id)
            option.setOnClickListener { prefs.edit().putInt(ScenePreferences.LIGHT_MODE,index).apply() }
        }
        content.addView(lights)
        content.body("Automatic mode transitions smoothly around the sunrise and sunset hours below; no location permission required.",muted,13f)
        content.slider("Sunrise hour", ScenePreferences.SUNRISE, 4, 11, 7, ":00")
        content.slider("Sunset hour", ScenePreferences.SUNSET, 15, 23, 19, ":00")

        content.section("BATTERY & PERFORMANCE")
        content.slider("Animation frame rate", ScenePreferences.FPS, 10, 30, 24, " FPS")
        content.body("Animation and sensor tracking stop when the live wallpaper isn't visible. For best battery life choose 15 FPS and reduced parallax.",muted,13f)
        val setWallpaperButton = Button(this).apply {
            text = "SET LIVE WALLPAPER"
            setTextColor(Color.WHITE)
            setBackgroundColor(red)
            setOnClickListener { launchPreview() }
        }
        val buttonParams = LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(26) }
        content.addView(setWallpaperButton,buttonParams)
        content.body("Original artwork retained in the project. Built for the S26 Ultra, responsive to other screen sizes.",muted,12f)
    }

    private fun LinearLayout.heading(textValue: String, size: Float) {
        addView(TextView(this@SettingsActivity).apply {
            text = textValue
            textSize = size
            setTextColor(ink)
            setTypeface(null, 1)
            letterSpacing = .08f
            setPadding(0,0,0,dp(6))
        })
    }

    private fun LinearLayout.section(textValue: String) {
        val label = TextView(this@SettingsActivity).apply {
            text = textValue
            textSize = 13f
            letterSpacing = .12f
            setTextColor(red)
            setTypeface(null,1)
            setPadding(0,dp(28),0,dp(12))
        }
        addView(label)
    }

    private fun LinearLayout.body(message: String, color: Int = muted, size: Float = 14f) {
        addView(TextView(this@SettingsActivity).apply {
            text = message
            setTextColor(color)
            textSize = size
            setPadding(0,dp(4),0,dp(9))
        })
    }

    private fun LinearLayout.toggle(title: String, key: String, default: Boolean) {
        addView(Switch(this@SettingsActivity).apply {
            text = title
            textSize = 16f
            setTextColor(ink)
            isChecked = prefs.getBoolean(key,default)
            setPadding(0,dp(10),0,dp(10))
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key,checked).apply() }
        })
    }

    private fun LinearLayout.slider(title: String,key: String,minValue: Int,maxValue: Int,
                                    defaultValue: Int,suffix: String) {
        val block = LinearLayout(this@SettingsActivity).apply { orientation = LinearLayout.VERTICAL }
        val label = TextView(this@SettingsActivity).apply {
            textSize = 15f
            setTextColor(ink)
            setPadding(0,dp(11),0,0)
        }
        val slider = SeekBar(this@SettingsActivity).apply {
            max = maxValue-minValue
            progress = prefs.getInt(key,defaultValue).coerceIn(minValue,maxValue)-minValue
        }
        fun update(p: Int) { label.text = "$title  ·  ${p+minValue}$suffix" }
        update(slider.progress)
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                update(progress)
                if (fromUser) prefs.edit().putInt(key,progress+minValue).apply()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        block.addView(label)
        block.addView(slider)
        addView(block)
    }

    private fun dp(value: Int): Int = (resources.displayMetrics.density*value).toInt()

    private fun launchPreview() {
        try {
            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(this@SettingsActivity,MercsLairService::class.java))
            }
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }
}
