package com.mercslair.wallpaper

import android.app.WallpaperManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.util.Log
import android.graphics.Shader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Pure native live wallpaper: Canvas surface, photographic rotor, sensor-based 2.5D mesh. */
class MercsLairService : WallpaperService() {
    override fun onCreateEngine(): Engine = LairEngine()

    private inner class LairEngine : Engine(), SensorEventListener,
        SharedPreferences.OnSharedPreferenceChangeListener {
        private val scheduler = Handler(Looper.getMainLooper())
        private val prefs = ScenePreferences.get(this@MercsLairService)
        private val sensors = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        private var motionSensor: Sensor? = null
        private var sensorRegistered = false
        private var visibleNow = false
        private var surfaceReady = false
        private var original: Bitmap? = null
        private var rotor: Bitmap? = null
        private var stationaryPole: Bitmap? = null
        private var depth: Bitmap? = null
        private var depthAtMesh = FloatArray((MESH_X + 1) * (MESH_Y + 1))
        private val verts = FloatArray((MESH_X + 1) * (MESH_Y + 1) * 2)
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var baseYaw = 0f
        private var basePitch = 0f
        private var baseRoll = 0f
        private var hasReference = false
        private var targetX = 0f
        private var targetY = 0f
        private var smoothX = 0f
        private var smoothY = 0f
        private var launcherOffset = 0f
        private var fanAngle = 0f
        private var lastFrameNs = 0L
        private var lastLightCheckMs = 0L
        private var cachedPhase = 0f
        private val rotation = FloatArray(9)
        private val orientation = FloatArray(3)
        private val runnable = Runnable { renderAndSchedule() }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(false)
            prefs.registerOnSharedPreferenceChangeListener(this)
            try {
                fun bitmap(file: String): Bitmap = assets.open(file).use {
                    BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inScaled = false })
                        ?: error("Could not decode $file")
                }
                original = bitmap("scene_base.webp")
                rotor = bitmap("fan_rotor.png")
                stationaryPole = bitmap("hub_pole.png")
                depth = bitmap("depth.png")
                sampleMeshDepth()
            } catch (error: Exception) {
                Log.e("MercsLair", "Could not load wallpaper assets", error)
            }
            motionSensor = sensors.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
                ?: sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
            registerSensorIfNeeded()
        }

        private fun sampleMeshDepth() {
            val bmp = depth ?: return
            var k = 0
            for (row in 0..MESH_Y) {
                for (col in 0..MESH_X) {
                    val x = ((col.toFloat() / MESH_X) * (bmp.width - 1)).toInt()
                    val y = ((row.toFloat() / MESH_Y) * (bmp.height - 1)).toInt()
                    depthAtMesh[k++] = Color.red(bmp.getPixel(x, y)) / 255f
                }
            }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            visibleNow = visible
            if (visible) {
                lastFrameNs = 0L
                lastLightCheckMs = 0L
                hasReference = false
                registerSensorIfNeeded()
                scheduleImmediately()
            } else {
                scheduler.removeCallbacks(runnable)
                unregisterSensor()
            }
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            surfaceReady = true
            scheduleImmediately()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            scheduleImmediately()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            surfaceReady = false
            scheduler.removeCallbacks(runnable)
            super.onSurfaceDestroyed(holder)
        }

        override fun onOffsetsChanged(xOffset: Float, yOffset: Float, xOffsetStep: Float,
                                      yOffsetStep: Float, xPixelOffset: Int, yPixelOffset: Int) {
            launcherOffset = ((xOffset - .5f) * 2f).coerceIn(-1f, 1f)
        }

        override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
            registerSensorIfNeeded()
            lastLightCheckMs = 0L
            scheduleImmediately()
        }

        private fun registerSensorIfNeeded() {
            val shouldEnable = visibleNow && prefs.getBoolean(ScenePreferences.MOTION_ENABLED, true)
            if (!shouldEnable) {
                unregisterSensor()
                targetX = 0f
                targetY = 0f
                return
            }
            if (!sensorRegistered && motionSensor != null) {
                hasReference = false
                sensorRegistered = sensors.registerListener(this, motionSensor, SensorManager.SENSOR_DELAY_GAME)
            }
        }

        private fun unregisterSensor() {
            if (sensorRegistered) {
                sensors.unregisterListener(this)
                sensorRegistered = false
            }
        }

        override fun onSensorChanged(event: SensorEvent) {
            if (event.sensor.type != Sensor.TYPE_GAME_ROTATION_VECTOR &&
                event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
            SensorManager.getRotationMatrixFromVector(rotation, event.values)
            SensorManager.getOrientation(rotation, orientation)
            val yaw = orientation[0]
            val pitch = orientation[1]
            val roll = orientation[2]
            if (!hasReference) {
                baseYaw = yaw
                basePitch = pitch
                baseRoll = roll
                hasReference = true
            }
            // Small angles keep the depth illusion tasteful; no large camera swings.
            targetX = (angleDelta(roll, baseRoll) / .24f).coerceIn(-1f, 1f)
            targetY = (angleDelta(pitch, basePitch) / .24f).coerceIn(-1f, 1f)
        }

        private fun angleDelta(a: Float, b: Float): Float {
            val tau = (2.0 * PI).toFloat()
            var diff = (a - b) % tau
            if (diff > PI) diff -= tau
            if (diff < -PI) diff += tau
            return diff
        }

        override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) = Unit

        private fun scheduleImmediately() {
            scheduler.removeCallbacks(runnable)
            if (visibleNow && surfaceReady) scheduler.post(runnable)
        }

        private fun renderAndSchedule() {
            if (!visibleNow || !surfaceReady) return
            val nowNs = SystemClock.elapsedRealtimeNanos()
            var dt = if (lastFrameNs == 0L) 0f else (nowNs - lastFrameNs) / 1_000_000_000f
            dt = dt.coerceIn(0f, .08f)
            lastFrameNs = nowNs

            val rpm = prefs.getInt(ScenePreferences.FAN_SPEED, 3).coerceIn(1, 8)
            if (prefs.getBoolean(ScenePreferences.FAN_ENABLED, true)) {
                fanAngle = (fanAngle + dt * rpm * 6f) % 360f
            }
            val damping = 1f - kotlin.math.exp(-dt * 6f)
            smoothX += (targetX - smoothX) * damping
            smoothY += (targetY - smoothY) * damping

            val timeMs = System.currentTimeMillis()
            if (lastLightCheckMs == 0L || timeMs - lastLightCheckMs > 10_000L) {
                cachedPhase = currentPhase()
                lastLightCheckMs = timeMs
            }
            var canvas: Canvas? = null
            try {
                canvas = try { surfaceHolder.lockHardwareCanvas() }
                         catch (_: Exception) { surfaceHolder.lockCanvas() }
                canvas?.let { drawScene(it, cachedPhase) }
            } catch (error: Exception) {
                // Surface can be transiently unavailable during unlock / launcher transitions.
                Log.w("MercsLair", "Frame unavailable", error)
            } finally {
                if (canvas != null) {
                    try { surfaceHolder.unlockCanvasAndPost(canvas) } catch (_: Exception) { }
                }
            }
            if (visibleNow && surfaceReady) {
                val fps = prefs.getInt(ScenePreferences.FPS, 24).coerceIn(10, 30)
                scheduler.postDelayed(runnable, (1000L / fps))
            }
        }

        /** 0 = bright day, 1 = sunset/golden hour, 2 = nighttime. */
        private fun currentPhase(): Float {
            when (prefs.getInt(ScenePreferences.LIGHT_MODE, 0)) {
                1 -> return 0f
                2 -> return 1f
                3 -> return 2f
            }
            val cal = Calendar.getInstance()
            val t = (cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)).toFloat()
            val sunrise = prefs.getInt(ScenePreferences.SUNRISE, 7).coerceIn(4, 11) * 60f
            val sunset = prefs.getInt(ScenePreferences.SUNSET, 19).coerceIn(15, 23) * 60f
            fun blend(t0: Float, t1: Float): Float {
                val q = ((t - t0) / (t1 - t0)).coerceIn(0f, 1f)
                return q * q * (3f - 2f * q)
            }
            return when {
                t < sunrise - 50f -> 2f
                t < sunrise + 40f -> 2f * (1f - blend(sunrise - 50f, sunrise + 40f))
                t < sunset - 90f -> 0f
                t < sunset - 15f -> blend(sunset - 90f, sunset - 15f)
                t < sunset + 70f -> 1f + blend(sunset - 15f, sunset + 70f)
                else -> 2f
            }
        }

        private fun drawScene(canvas: Canvas, phase: Float) {
            val scene = original ?: return
            val width = canvas.width.toFloat()
            val height = canvas.height.toFloat()
            canvas.drawColor(Color.BLACK)
            val scale = max(width / scene.width, height / scene.height) * 1.052f
            val left = (width - scene.width * scale) / 2f
            val top = (height - scene.height * scale) / 2f
            val strength = prefs.getInt(ScenePreferences.MOTION_STRENGTH, 45).coerceIn(0, 100) / 100f
            val mx = smoothX * strength * 29f * scale + launcherOffset * 5.5f * scale
            val my = smoothY * strength * 24f * scale

            val rgb = lightingFactors(phase)
            paint.colorFilter = ColorMatrixColorFilter(floatArrayOf(
                rgb[0],0f,0f,0f,0f,
                0f,rgb[1],0f,0f,0f,
                0f,0f,rgb[2],0f,0f,
                0f,0f,0f,1f,0f
            ))
            // Mesh is warped minimally according to an authored approximate depth field.
            // Unlike drawing offset duplicates, there are no exposed holes between layers.
            var i = 0
            var idx = 0
            for (y in 0..MESH_Y) {
                for (x in 0..MESH_X) {
                    val z = depthAtMesh[idx++]
                    val parallax = .3f + z * .7f
                    verts[i++] = left + (scene.width.toFloat() * x / MESH_X) * scale + mx * parallax
                    verts[i++] = top + (scene.height.toFloat() * y / MESH_Y) * scale + my * parallax
                }
            }
            try {
                canvas.drawBitmapMesh(scene, MESH_X, MESH_Y, verts, 0, null, 0, paint)
            } catch (_: UnsupportedOperationException) {
                canvas.drawBitmap(scene, null,
                    RectF(left,top,left+scene.width*scale,top+scene.height*scale),paint)
            }

            rotor?.let { blades ->
                // Fan is elliptical due to looking up through the cooling tower.
                // Rotate in local circular coordinates BEFORE projecting to the ellipse.
                canvas.save()
                canvas.translate(left + 505f*scale + mx*.76f, top + 946f*scale + my*.76f)
                canvas.scale((482f / blades.width) * scale, (270f / blades.height) * scale)
                canvas.rotate(fanAngle)
                canvas.drawBitmap(blades, -blades.width/2f, -blades.height/2f, paint)
                canvas.restore()
            }
            stationaryPole?.let { hub ->
                val x = left + (450f * scale) + mx * .76f
                val y = top + (904f * scale) + my * .76f
                canvas.save()
                canvas.translate(x,y)
                canvas.scale(scale, scale)
                canvas.drawBitmap(hub,0f,0f,paint)
                canvas.restore()
            }
            paint.colorFilter = null
            val night = (phase - 1f).coerceIn(0f, 1f)
            if (night > .01f) {
                // Subtle illumination from Merc's monitors, proportional to night darkness.
                val px = left + (515f * scale) + mx*.8f
                val py = top + (1346f * scale) + my*.8f
                val radius = 155f * scale
                val alpha = (night * 68).toInt().coerceIn(0,255)
                glowPaint.shader = RadialGradient(px,py,radius,
                    intArrayOf(Color.argb(alpha, 62,170,255), Color.argb(0,25,110,245)),
                    null,Shader.TileMode.CLAMP)
                canvas.drawCircle(px,py,radius,glowPaint)
                glowPaint.shader = null
            }
        }

        private fun lightingFactors(phase: Float): FloatArray {
            val day = floatArrayOf(1f,1f,1f)
            val dusk = floatArrayOf(1.06f,.82f,.70f)
            val night = floatArrayOf(.33f,.42f,.60f)
            val a = if (phase <= 1f) day else dusk
            val b = if (phase <= 1f) dusk else night
            val t = if (phase <= 1f) phase else phase - 1f
            return FloatArray(3) { a[it] * (1f-t) + b[it]*t }
        }

        override fun onDestroy() {
            scheduler.removeCallbacks(runnable)
            unregisterSensor()
            prefs.unregisterOnSharedPreferenceChangeListener(this)
            listOf(original,rotor,stationaryPole,depth).forEach { it?.recycle() }
            original = null
            rotor = null
            stationaryPole = null
            depth = null
            super.onDestroy()
        }
    }

    companion object {
        private const val MESH_X = 18
        private const val MESH_Y = 40
    }
}
